fx_version 'cerulean'
game        'gta5'

author      'M1-Dev (QBCore port)'
description 'One-shot headshots (any range) with kill-feed credit'
version     '2.0.0-qb'

client_script 'client.lua'
server_script 'server.lua'

dependencies {
    'qb-core'
}
